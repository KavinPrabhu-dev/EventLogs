# ListView-CRUD
Simple LstView CRUD Example with ArrayList. View project's tutorial at http://camposha.info/source/android-listview-crud-add-update-delete-source/

Basically we see how to add update and delete data to and from a listview. We use no data source, only a listview and an arraylist.

Let's go.
